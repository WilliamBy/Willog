---
categories:
  - 技术
  - 指南
abbrlink: 369ceeb5
tags: Command
---
# CMD 指令备忘

- Process 类
  - tasklist 列出所有进程
  - taskkill /pid xxx -f 杀死指定id process

