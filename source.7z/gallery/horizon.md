---

title: METAL HUNTER
katex: false
variant: cyberpunk
plugins:
	gallery: true
---

{% card  img="https://i.loli.net/2020/11/06/1Xdv9FwZziHhDW6.png" %}
{% endcard %}

<div class="justified-gallery">

![初遇长颈兽](https://gitee.com/BAIDI-CODER/PicGo/raw/master/img/20201024152515.jpg)
![遗迹](https://i.loli.net/2020/11/08/Pum7XIpiGBgSrke.png)
![荣光](https://i.loli.net/2020/10/25/Q8ExtGXNVJ42rzi.png)
![夜袭强盗窝](https://i.loli.net/2020/10/25/AlHQaMRnWLzhGwE.png)
![超控时刻](https://i.loli.net/2020/10/25/53pjhQmPxl7UcOZ.png)
![超控解锁](https://i.loli.net/2020/11/01/bTV965zucD4EXZx.png)
![寻猎风暴鸟](https://i.loli.net/2020/11/01/ZgK3dUyaJ86YOEj.png)
![绳枪束缚](https://i.loli.net/2020/11/01/YG4IvXmTC5VjDrM.png)
![战术撤退](https://i.loli.net/2020/11/08/uMq1kC5QbtsfYE4.png)
![九死一生](https://i.loli.net/2020/11/08/A2tVsXkoI6Yh8Em.png)
![坟屯巨兽](https://i.loli.net/2020/11/06/1Xdv9FwZziHhDW6.png)
![哈迪斯](https://i.loli.net/2020/12/12/T1GwiohDmpFlUX7.png)

</div>

{% card  img="https://i.loli.net/2020/11/08/rkT5VelAvBRaUp8.png" %}
{% endcard %}

<div class="justified-gallery">

![试炼](https://i.loli.net/2020/10/25/CcahEO9upzUHIRw.png)
![雷霆牙](https://i.loli.net/2020/10/25/sfPGZBceEV2nwRp.png)
![狩猎滑翔者](https://i.loli.net/2020/10/25/5yVBlh1iUPYuJzo.png)
![子午城桥](https://i.loli.net/2020/10/25/FREWSPVfcbaCD95.png)
![惬意](https://i.loli.net/2020/11/01/HhKlnfpeDCAN8qG.png)
![远望](https://i.loli.net/2020/11/01/9XFm3KY74Hhenc8.png)
![星光](https://i.loli.net/2020/10/25/lnSMgQxG43epzV2.png)
![闪电颚](https://i.loli.net/2020/10/25/cfCDiRxtydLlHo1.png)
![斗兽场](https://i.loli.net/2020/11/21/5GdBqVU7KQX4xvZ.png)
![践踏者](https://i.loli.net/2020/11/21/xgEpSOJL1AwHi67.png)
![日蚀](https://i.loli.net/2020/11/21/Pi5IgyuaV2A4odW.png)
![战火](https://i.loli.net/2020/12/12/3FPu2DtNzq5vyhV.png)

</div>

{% card  img="https://i.loli.net/2020/11/08/WRTlaLN86vHrzZO.png" %}
{% endcard %}

<div class="justified-gallery">

![整装待发](https://i.loli.net/2020/11/08/zpno2tJGZBh9fvF.png)
![探秘](https://i.loli.net/2020/11/08/TOQpvxiNzE4moL8.png)
![造者尽头](https://i.loli.net/2020/11/08/QdDnvsyM8AJVBuP.png)
![坟屯](https://i.loli.net/2020/11/06/Vrx9qlOUj53QZNL.png)
![冰原猎手](https://i.loli.net/2020/10/25/o124mA73UPWd8RK.png)
![盖亚主星](https://i.loli.net/2020/12/12/CWmqeJ1B7UldNis.png)
![风暴鸟](https://i.loli.net/2020/12/12/9ngPGthFE7ayQ65.png)
![终焉之战](https://i.loli.net/2020/12/12/zb2ur3lG7HgjMOJ.png)

</div>

<button class="button is-success is-fullwidth"  href="./index.html" target="view_self" style="margin-top: 5px;">
<a href="./index.html" target="view_self">
    <span class="icon" style="color: black">
      <i class="fa fa-home" style="color: black"></i>
    </span>
    <span href="./index.html" target="view_self" style="color: black;">back to gallery</span>
</a>
</button>